package com.example.islandsfisher

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private val fields = LinkedHashMap<String, EditText>()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 30, 40, 30) }
        fun label(t: String) = col.addView(TextView(this).apply { text = t })
        fun field(key: String, t: String, def: String) {
            label(t)
            val e = EditText(this).apply { setText(def); inputType = InputType.TYPE_CLASS_NUMBER; setSingleLine() }
            fields[key] = e; col.addView(e)
        }
        fun button(t: String, f: () -> Unit) = col.addView(Button(this).apply { text = t; setOnClickListener { f() } })

        label("Islands Fisher\n1) Allow overlay  2) Enable accessibility service  3) Start, then switch to Roblox.\nDrag the red box over the water where the bobber lands.")
        field("thr", "Bobber movement needed to reel in (% of box changing)", "3")
        field("box", "Box size (px)", "140")
        field("cast", "Wait after casting before watching (ms)", "2000")
        field("reel", "Wait after reeling before recasting (ms)", "3000")
        field("timeout", "Recast if no bite after (seconds)", "15")

        button("1. Allow overlay") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        button("2. Enable accessibility service") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        button("3. Start") {
            when {
                !Settings.canDrawOverlays(this) -> toast("Allow overlay first")
                TapService.instance == null -> toast("Enable the accessibility service first")
                else -> startActivityForResult(
                    getSystemService(MediaProjectionManager::class.java).createScreenCaptureIntent(), 1)
            }
        }
        setContentView(ScrollView(this).apply { addView(col) })
    }

    override fun onActivityResult(req: Int, code: Int, data: Intent?) {
        if (req != 1 || code != RESULT_OK || data == null) return
        fun v(k: String) = fields[k]!!.text.toString().toIntOrNull() ?: 0
        val i = Intent(this, BotService::class.java)
            .putExtra("code", code).putExtra("data", data)
            .putExtra("thr", v("thr")).putExtra("box", v("box"))
            .putExtra("cast", v("cast")).putExtra("reel", v("reel")).putExtra("timeout", v("timeout"))
        startForegroundService(i)
        moveTaskToBack(true)
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
